import smtplib
import random
def email(recv,booking_id,payment_id,phno):
    pin = random.randint(1000,9999)
    sender = 'purnasaikumarreddy@outlook.com'
    receivers = recv
    message = """
Hi customer,\nYour cylinder will be delivered within 2-3 days by our
Super gas Delivery Agent \nPhone: +91406782000\nPIN: """+str(pin)+"""
your booking id is """+str(booking_id)+"""
your payment id is """+str(payment_id)+"""
your phone Number is """+str(phno)+"""
\nTo ensure your safety, the Delivery Agent will drop the package at your doorstep, ring the doorbell and then move back 2 meters while waiting for you to collect your package. If you are in a containment zone, the agent will call you and request you to collect your package from the nearest accessible point while following the same No-Contact delivery process.
    """
    smtp = smtplib.SMTP("smtp.office365.com",587)
    smtp.starttls()
    smtp.login('purnasaikumarreddy@outlook.com', 'Sai@/0806')
    smtp.sendmail(sender, receivers, message)
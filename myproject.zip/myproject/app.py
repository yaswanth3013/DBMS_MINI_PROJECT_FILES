
from datetime import date, datetime

from django.shortcuts import render
from flask import *
import sqlite3
import random
import uuid
import mail,mail2

app = Flask(__name__)


@app.route("/",methods = ["POST","GET"])

def login():
    global phno
    global cust_id , name, gmail
    cust_id = random.randint(10000,999999)
    if request.method == "GET":
        with sqlite3.connect("register.db") as con:  
            con.execute('''CREATE TABLE IF NOT EXISTS customer(
                cust_id int not null,
                name varchar(20) not null,
                phno int not null,
                aadhar_no int not null,
                gmail varchar(40) not null,
                address varchar(40) not null,
                primary key (phno)
                )''')
            con.commit()
        with sqlite3.connect("register.db") as con: 
            con.execute('''CREATE TABLE IF NOT EXISTS payment_details (
                payment_id varchar(30) not null,
                payment_date varchar(30) not null,
                phno int not null,
                FOREIGN KEY(phno) REFERENCES customer(phno)
                )''')
            con.commit()
        return render_template('dbms_pg1.html')
    else:
        global gmail
        name = request.form['name']
        phno = request.form['phno']
        aadhar = request.form['aadhar']
        gmail = request.form["gmail"]
        address = request.form["address"]
        with sqlite3.connect("register.db") as con:
            con.execute(
                "INSERT into customer (cust_id,name, phno , aadhar_no,gmail,address) values (?,?,?,?,?,?)",(cust_id,name, phno, aadhar, gmail,address))
        mail.email(gmail,cust_id)
        return render_template('dbms_pg1.html')



@app.route("/new_user")
def new_user():
    return render_template('dbms_pg2.html')

@app.route("/home",methods = ["Post"])
def home():
    global phno,cust_id
    phno = request.form['phno']
    cust_id = request.form['cust_id']
    con = sqlite3.connect("register.db")
    cursor_obj = con.cursor()
    cursor_obj.execute("SELECT phno, cust_id FROM customer")
    data = cursor_obj.fetchall()
    lst_phno = []
    lst_custid = []
    for i in data:
        for r in range(1):
            lst_phno.append(str(i[0]))
            lst_custid.append(str(i[1]))
    
    dict1 = dict()
    for i in range(len(lst_custid)):
        dict1[lst_phno[i]] = str(lst_custid[i])
    if str(cust_id) == dict1[phno] : return render_template('dbms_pg3.html',cust_id = cust_id)
    else: return "Invalid Credentials" 


@app.route("/quick_book")
def quick_book():
    if request.method == "GET":
        with sqlite3.connect("register.db") as con:  
            con.execute('''CREATE TABLE IF NOT EXISTS booking_details (
                state varchar(30) not null,
                district varchar(30) not null,
                distributor_name varchar(30) not null,
                booking_id int unique,
                booking_date varchar(40) not null,
                phno int not null,
                FOREIGN KEY(phno) REFERENCES customer(phno)
                )''')
            con.commit()
        return render_template('quick_pg4.html') 
    else:
        return render_template('pay_pg8.html')


@app.route("/payment",methods = ["post"])
def payment():
    booking_id = random.randint(100000,9999999)
    if request.method == "post":
        state = request.form['state']
        district = request.form['district']
        distributor_name = request.form['distributor']
        with sqlite3.connect("register.db") as con:
            con.execute(
        "INSERT into booking_details(state, district , distributor_name, booking_id,booking_date, phno) values (?,?,?,?,?,?)",(state, district, distributor_name, booking_id, datetime.now(),phno))
        return render_template("pay_pg8.html")
    else:
        state = request.form['state']
        district = request.form['district']
        distributor_name = request.form['distributor']
        with sqlite3.connect("register.db") as con:
            con.execute(
        "INSERT into booking_details(state, district , distributor_name, booking_id,booking_date,phno) values (?,?,?,?,?,?)",(state, district, distributor_name, booking_id, datetime.now(),phno))
        return render_template("pay_pg8.html")



@app.route("/subsidy")
def subsidy():
    return render_template("subsidy_pg5.html")

@app.route("/pahal")
def pahal():
    return render_template("pahal_pg6.html")

@app.route("/feedback")
def feedback():
    return render_template("feedback_pg7.html")

@app.route("/success",methods=["post"])
def success():
    if request.method == "post":
        txn_id = random.randint(12345656474,789010283638393638)
        with sqlite3.connect("register.db") as con:
            con.execute(
                "INSERT into payment_details(payment_id, payment_date , phno) values (?,?,?)",(txn_id, datetime.now(),phno))
        return render_template('success.html')
    else:
        txn_id = random.randint(12345656474,789010283638393638)
        with sqlite3.connect("register.db") as con:
            con.execute(
                "INSERT into payment_details(payment_id, payment_date , phno) values (?,?,?)",(txn_id, datetime.now(),phno))
        con = sqlite3.connect("register.db")
        cursor_obj = con.cursor()
        cursor_obj.execute("SELECT gmail FROM customer where phno = "+"'"+phno+"'"+"")
        data = cursor_obj.fetchall()
        lst_gmail = []
        for i in data:
            for j in i:
                lst_gmail.append(j)
        cursor_obj.execute("SELECT booking_id FROM booking_details where phno = "+"'"+phno+"'"+"")
        data = cursor_obj.fetchall()
        lst_bookid = []
        for i in data:
            for j in i:
                lst_bookid.append(j)
        cursor_obj.execute("SELECT payment_id FROM payment_details where phno = "+"'"+phno+"'"+"")
        data = cursor_obj.fetchall()
        lst_paymentid = []
        for i in data:
            for j in i:
                lst_paymentid.append(j)
        mail2.email(lst_gmail[0],lst_bookid[0],lst_paymentid[0],phno)
        return render_template('success.html',txn_id = txn_id)


if __name__ == "__main__":
    app.run(debug = True)
